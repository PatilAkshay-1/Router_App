
const Navbar = () => {
    return (
        <>
            This is Navbar
        </>
    )
}

export default Navbar